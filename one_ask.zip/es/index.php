<!DOCTYPE html>
<html lang="es">
<head>
	<title>One Ask</title>
	<link rel="stylesheet" href="../css/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="../css/style-css.css">
	<link rel="stylesheet" href="../fonts/font-awesome/css/font-awesome.min.css">

</head>
<style>
	.chat{
		/* descomentar para quitar el chat */
		/*display: none*/
	}
</style>
<body>
	<header>
		<nav class="navbar navbar-expand-md bg-primary navbar-dark">
			<a	class="navbar-brand img-responsive img-logo" href="#"><img src="../img/logo/logo.png" alt="one_ask"><h1 class="text-logo">One Ask</h1></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
				<ul class="navbar-nav">
					<li class="nav-item">
						<a class="nav-link active-bar" href="#"><i class="fa fa-home"></i>Inicio</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#"><i class="fa fa-bell"></i>Publicaciones</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#"><i class="fa fa-group"></i>Seguidores</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#"><i class="fa fa-bar-chart"></i>Estadisticas</a>
					</li>
				</ul>
			</div>
		</nav>
	</header>
	<section class="container-row">
		<div class="row">
			<div class="col-sm-12 mt-5">
				<div class="card mt-5 mb-4 portada">
					<div class="card-body container-img">
						<img src="../datos/user/nelson/banner/banner.jpg" alt="">
						<div class="photo-profile"><img src="../datos/user/nelson/photoProfile/photo.png" alt=""></div>
						<div class="paralax-portada">
							<div class="name-portada"><h1># Nelson Portillo</h1></div>
						</div>
					</div>
				</div>
			</div>
			<article class="col-sm-12 col-md-4 col-xl-6">
				<div class="card mb-3">
					<div class="card-header bg-primary">
						<h3 class="title-follow"><i class="fa fa-group mr-3"></i>Seguidores</h3>
					</div>
					<div class="card-body">
					<p>Aquí mostrará los seguidores, encuestas, y datos estadisticos.</p>
						
					</div>
				</div>
				<div class="card">
					<div class="card-header bg-primary">
						<h3 class="title-follow"><i class="fa fa-heart mr-3"></i>Me gusta</h3>
					</div>
					<div class="card-body">
					<p>Aquí apareceran los resultados que me gustan y posibles encuestas que seguir.</p>
						
					</div>
				</div>
			</article>
			<section class="col-sm-12 col-md-8 col-xl-6">
				<div class="col-12 p-0">
					<ul class="breadcrumb">
						<li class="breadcrumb-item"><a href="#"><i class="fa fa-home mr-2 ml-3"></i>Inicio</a></li>
						<li class="breadcrumb-item"><a href="#">Nelson Portillo</a></li>
						<li class="breadcrumb-item active">Post</li>
					</ul>
				</div>
				<!-- post -->
				<article class="card my-3 post">
					<div class="card-body">
						<div class="photo-post">
							<img src="../datos/user/otros/user_1.jpg" alt="user_1">
							<div class="letter-post">
								<h4>Angela Velgano 
									<p class="arrow-post dropdown-toggle" id="post_#1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></p> 
									<div class="dropdown-menu dropdown-menu-right" aria-labelledby="post_#1">
									    <a href="#" class="dropdown-item"><i class="fa fa-share mr-2"></i>Compartir</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-user-plus mr-2"></i>Simpatizar</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-low-vision mr-2"></i>Bloquear</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-hashtag mr-2"></i>Responder Encuesta</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-comments-o mr-2"></i>Enviar Mensaje</a>
									</div>
									<p class="float-right mr-4">20/4/2019</p>
								</h4>
								<p>Lorem ipsum dolor.</p>
							</div>
						</div>
						<h3 class="text-primary">¿Porqué las app de Android son tan costosas?</h3>
						<div class="post-descripion">
							<!-- lorem de 120 caracteres -->
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus, labore, incidunt corporis tempore praesentium necessitatibus possimus illum. Nisi error qui vero, magnam accusantium rerum mollitia possimus voluptate, natus earum fuga aut nesciunt libero delectus maxime omnis. Quis, est odit! Ipsam, culpa nostrum inventore eligendi enim sit! Libero harum recusandae est numquam quibusdam veritatis necessitatibus aspernatur deserunt quia adipisci, tempora quas unde accusantium beatae aliquid reprehenderit quidem nam, odit. Consequatur commodi possimus explicabo esse ipsa tempora eaque, laudantium, quis provident facilis fuga saepe ex reiciendis fugit est, vitae debitis, excepturi autem recusandae dicta doloremque? Optio corrupti architecto hic. Totam illo provident obcaecati, itaque! Dolor tempore inventore quod cumque at facere dolores officiis maiores, similique, cupiditate repudiandae. Optio totam beatae ipsa delectus.</p>
						</div>
						<div class="post-img"><img src="../datos/user/nelson/post/post_1.jpg" alt="primerPost"></div>
						<div class="tools-post">
							<div class="item-1"><i class="fa fa-heart-o mr-2"></i>Me gusta</div>
							<div class="item-2"><i class="fa fa-share mr-2"></i>Compartir</div>
							<div class="item-3" data-identificador="Post-01"><i class="fa fa-comments-o mr-2"></i>Responder</div>
						</div>
						<div class="box-comments">
							<div class="img-user"><img src="../datos/user/nelson/photoProfile/photo.png" alt=""></div>
							<div class="form-input">
								<form>
									<textarea type="text" id="Post-01" placeholder="Escriba un comentario"></textarea>
								</form>
							</div>
						</div>
					<div>
				</article>
				<!-- / post -->
				<!-- post -->
				<article class="card my-3 post">
					<div class="card-body">
						<div class="photo-post">
							<img src="../datos/user/otros/user_2.jpg" alt="user_2">
							<div class="letter-post">
								<h4>Marta Martinez 
									<p class="arrow-post dropdown-toggle" id="post_#1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></p> 
									<div class="dropdown-menu dropdown-menu-right" aria-labelledby="post_#2">
									    <a href="#" class="dropdown-item"><i class="fa fa-share mr-2"></i>Compartir</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-user-plus mr-2"></i>Simpatizar</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-low-vision mr-2"></i>Bloquear</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-hashtag mr-2"></i>Responder Encuesta</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-comments-o mr-2"></i>Enviar Mensaje</a>
									</div>
									<p class="float-right mr-4">20/4/2019</p>
								</h4>
								<p>Lorem ipsum dolor.</p>
							</div>
						</div>
						<h3 class="text-primary">¿Por qué no se me ocurren ideas para un proyecto?</h3>
						<div class="post-descripion">
							<!-- lorem de 120 caracteres -->
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex excepturi cumque ab mollitia, tenetur, earum temporibus laborum ea, a suscipit id, dolor blanditiis. Suscipit quisquam aut nihil quaerat et necessitatibus iusto cum vitae itaque provident, voluptate saepe sunt quidem neque fugiat laudantium dicta amet eos totam obcaecati doloribus quas! Nesciunt consequuntur odio ut eos provident similique vitae voluptatem dicta ullam eaque, reprehenderit ea voluptatum asperiores pariatur quas adipisci soluta deleniti sint, molestiae nihil porro voluptate distinctio veritatis. Mollitia aspernatur obcaecati, molestias aut saepe at, praesentium excepturi laudantium architecto eveniet asperiores velit, dolor ipsa maxime earum magni odio quae ratione. Laudantium illum, rerum. Distinctio qui, veniam. Sit natus assumenda, harum minus ipsam, praesentium magnam dolore at accusamus eos aliquid nesciunt vel.</p>
						</div>
						<div class="post-img"><img src="../datos/user/nelson/post/post_2.jpg" alt="primerPost"></div>
						<div class="tools-post">
							<div class="item-1"><i class="fa fa-heart-o mr-2"></i>Me gusta</div>
							<div class="item-2"><i class="fa fa-share mr-2"></i>Compartir</div>
							<div class="item-3" data-identificador="Post-02"><i class="fa fa-comments-o mr-2"></i>Responder</div>
						</div>
						<div class="box-comments">
							<div class="img-user"><img src="../datos/user/nelson/photoProfile/photo.png" alt=""></div>
							<div class="form-input">
								<form>
									<textarea type="text" id="Post-02" placeholder="Escriba un comentario"></textarea>
								</form>
							</div>
						</div>
					<div>
				</article>
				<!-- / post -->
				<!-- post -->
				<article class="card my-3 post">
					<div class="card-body">
						<div class="photo-post">
							<img src="../datos/user/otros/user_3.jpg" alt="user_1">
							<div class="letter-post">
								<h4>Elena Sanchez 
									<p class="arrow-post dropdown-toggle" id="post_#3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></p> 
									<div class="dropdown-menu dropdown-menu-right" aria-labelledby="post_#3">
									    <a href="#" class="dropdown-item"><i class="fa fa-share mr-2"></i>Compartir</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-user-plus mr-2"></i>Simpatizar</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-low-vision mr-2"></i>Bloquear</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-hashtag mr-2"></i>Responder Encuesta</a>
									    <a class="dropdown-item" href="#"><i class="fa fa-comments-o mr-2"></i>Enviar Mensaje</a>
									</div>
									<p class="float-right mr-4">20/4/2019</p>
								</h4>
								<p>Lorem ipsum dolor.</p>
							</div>
						</div>
						<h3 class="text-primary">¿Qué es el diseño responsive, HTML?</h3>
						<div class="post-descripion">
							<!-- lorem de 120 caracteres -->
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis itaque tempore nesciunt fugiat dolores voluptates rem, incidunt quia sapiente id sit delectus quisquam iure facere tempora, error omnis molestias iste necessitatibus? Minus at deleniti sit quod maiores dolor, iste laudantium ad, ea similique rem ipsa, dicta ullam pariatur culpa aperiam laboriosam? Aliquid possimus, eius debitis ratione blanditiis? Dolore inventore, iste, debitis pariatur minus ratione maxime sed esse tenetur, vero asperiores voluptatum modi soluta. Architecto sunt voluptas rem culpa, tempore! Error nisi eum veritatis ipsam adipisci esse, rerum pariatur quisquam debitis nulla quasi optio veniam expedita molestias iste laudantium laboriosam doloribus minus eaque nostrum saepe maxime dolores! Commodi ex, illo necessitatibus ullam! Porro quasi veniam, ea ullam animi praesentium architecto vitae.</p>
						</div>
						<div class="post-img"><img src="../datos/user/nelson/post/post_3.png" alt="primerPost"></div>
						<div class="tools-post">
							<div class="item-1"><i class="fa fa-heart-o mr-2"></i>Me gusta</div>
							<div class="item-2"><i class="fa fa-share mr-2"></i>Compartir</div>
							<div class="item-3" data-identificador="Post-03"><i class="fa fa-comments-o mr-2"></i>Responder</div>
						</div>
						<div class="box-comments">
							<div class="img-user"><img src="../datos/user/nelson/photoProfile/photo.png" alt=""></div>
							<div class="form-input">
								<form>
									<textarea type="text" id="Post-03" placeholder="Escriba un comentario"></textarea>
								</form>
							</div>
						</div>
					<div>
				</article>
				<!-- / post -->
			</section>
			<section class="max-chat">
				<!-- chat -->
				<article class="chat">
					<p class="close-chat">X</p>
					<div class="bg-primary container-chat" data-toggle="tooltip" title="Nasser Mohamed" data-hide="nasser"><h3><p class="active"></p> Nasser Mohamed </h3></div>
					<div class="toggle-chat" id="chatId-nasser"> <!-- Id o clave unica del usuario -->
						<div class="msj-chat">
							<div class="tag">
								<!-- Mensaje por default -->
								<p class="tag-none">No hay mensajes</p>
							</div>
						</div>
						<div class="text-chat"><textarea placeholder="Escriba un Mensaje"></textarea></div>
					</div>
				</article>
				<!-- / chat -->
				<!-- chat -->
				<article class="chat">
					<p class="close-chat">X</p>
					<div class="bg-primary container-chat" data-toggle="tooltip" title="Nelson Portillo" data-hide="nelson"><h3><p class="active"></p> Nelson Portillo</h3></div>
					<div class="toggle-chat" id="chatId-nelson">
						<div class="msj-chat">
							<div class="tag">
								<!-- Ejemplo de Mensaje Recibido -->
								<p class="tag-recibido">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit, quae.</p>
								<!-- Ejemplo de Mensaje Enviado -->
								<p class="tag-enviado">Hola mundo</p>
								<!-- Ejemplo de Mensaje Recibido -->
								<p class="tag-recibido">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit, quae.</p>
							</div>
						</div>
						<div class="text-chat"><textarea placeholder="Escriba un Mensaje"></textarea></div>
					</div>
				</article>
				<!-- / chat -->
				<!-- chat -->
				<article class="chat">
					<p class="close-chat">X</p>
					<div class="bg-primary container-chat" data-toggle="tooltip" title="Angel Moreno" data-hide="angel"><h3><p class="desactive"></p> Angel Moreno</h3></div>
					<div class="toggle-chat" id="chatId-angel">
						<div class="msj-chat">
							<div class="tag">
								<!-- Ejemplo de Mensaje Recibido -->
								<p class="tag-recibido">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit, quae.</p>
								<!-- Ejemplo de Mensaje Enviado -->
								<p class="tag-enviado">Hola mundo</p>
								<!-- Ejemplo de Mensaje Recibido -->
								<p class="tag-recibido">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit, quae.</p>
							</div>
						</div>
						<div class="text-chat"><textarea placeholder="Escriba un Mensaje"></textarea></div>
					</div>
				</article>
				<!-- / chat -->
			</section>
		</div>
	</section>
	<footer class="bg-primary footer">
		<div class="col-sm-12">
			<p class="text-center py-3">© Corporación One Ask <script>document.write(new Date().getFullYear());</script></p>
		</div>		
	</footer>
	<script src="../js/jquery-3.3.1.js"></script>
	<script src="../js/bootstrap/asset/vendor/popper.min.js"></script>
	<script src="../js/bootstrap/asset/vendor/jquery-slim.min.js"></script>
	<script src="../js/bootstrap/bootstrap.min.js"></script>
	<script>
		$(document).ready(function() {
			$("a[href='#']").click(function(w) {
				e.preventDefault();
			});
			$('[data-toggle="tooltip"]').tooltip();
			$(".container-chat").click(function() {
				var nameHide = $(this).attr('data-hide');
				var elem = $("#chatId-" +nameHide);
				elem.fadeToggle();
			});
			$(".close-chat").click(function() {
				var nameHide = $(this).parent();
				console.log(nameHide);
				nameHide.remove();
			});
			$("div.item-1").click(function() {
				var elem = $(this).find('i');
				 elem.toggleClass('fa-heart').toggleClass('fa-heart-o');
			});
			$("div.item-2").click(function() {
				var elem = $(this);
				var i = '<i class="fa fa-share mr-2 text-success"></i>';
				 elem.html(i + "<span class='text-success'>Compartido</span>");
			});
			$("div.item-3").click(function() {
				var elem = $(this).attr('data-identificador');
				// document.getElementById(elem).focus();
				$("#"+elem).focus();
			});

		});
	</script>
</body>
</html>
<?php  


?>
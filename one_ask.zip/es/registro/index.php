<!DOCTYPE html>
<html lang="es">
<head>
	<title>Inicio de Sesión - One Ask</title>
	<link rel="stylesheet" href="../../css/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="../../css/style.css">

</head>
<body>

	<nav class="navbar navbar-expand-lg bg-primary">
		<a	class="navbar-brand img-responsive img-logo" href="#"><img src="../../img/logo/logo.png" alt="one_ask"><h1 class="text-logo">One Ask</h1></a>
		<button	class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	</nav>
	<div class="paralax"></div>
	<div class="z-index">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xl-12">
					<div class="welcome">
						<h1>Red Social de Encuesta</h1>
					</div>
					<div class="col-md-5" style="position: relative;">
						<div class="backround-img"></div>
					</div>
					<div class="col-md-7">
						<form class="bg-white p-5 form-user" id="registro">
							<div class="p-5">
								<h3>Registrar Usuario</h3>
							</div>
							<div class="col-sm-6 float-left pl-0 form-group">
								<label for="email">Nombre:</label>
								<input type="text" class="form-control" id="first_name" name="first_name" >
							</div>
							<div class="col-sm-6 float-left pl-0 form-group">
								<label for="email">Apellido:</label>
								<input type="text" class="form-control" id="last_name" name="last_name" >
							</div>
							<div class="form-group">
								<label for="email">Dirección de Correo:</label>
								<input type="email" class="form-control" id="email" name="email" >
							</div>
							<div class="form-group">
								<label for="pwd">Contraseña:</label>
								<input type="password" class="form-control" id="password" name="password" >
							</div>
							<div class="form-group">
								<label for="pwd">Repita la Contraseña:</label>
								<input type="password" class="form-control" id="r_password" name="r_password" >
							</div>
							<div class="form-group">
								<label for="email">Fecha de nacimiento:</label>
								<input type="date" class="form-control" id="date" name="date" >
							</div>

								<div class="col-sm-12 pl-0">
									<p class="d-inline-block"><a href="../login/">Inicia Sesión</a></p>
									<p class="d-inline-block float-right"><a href="#">¿Olvide mi contraseña?</a></p>
								</div>
							<div class="form-check">
								<label class="form-check-label">
								<input class="form-check-input" type="checkbox"> Recuerda me
							</label>
							</div>
								<button type="submit" class="btn btn-primary mt-3">Registro</button>
								<button type="reset" class="btn btn-primary mt-3">Reset</button>
								<div class="c-w100">
									<span id="msj" class="mb-5 py-1 w100 alert"></span>	
								</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script src="../../js/jquery-3.3.1.js"></script>
	<script src="../../js/jquery-validate/jquery.validate.min.js"></script>
	<script src="../../js/main.js"></script>
	<script src="../../js/bootstrap/bootstrap.min.js"></script>
</body>
</html>
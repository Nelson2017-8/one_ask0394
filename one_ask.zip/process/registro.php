<?php  
	function is_date($value) {
	    $value = explode('/', $value);

	    if(count($value) !== 3) return false;

	    return @checkdate ( $value[1] , $value[0] , $value[2] );
	}

	if (!empty($_POST)) {
		$error = "";

		// valido campor

		// nombre
		if (empty($_POST["first_name"])) {
			$error .= "Nombre Vació";
		}
		// apellido
		if (empty($_POST["last_name"])) {
			$error .= "\n Apellido Vació";
		}

		// email
		if (empty($_POST["email"])) {
			$error .= "\n Email Vació";
		}else if(!filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL)) {
	        $error .= "\n El correo no es válido";
	    }

	    // password
		if (empty($_POST["password"])) {
			$error .= "\n Contraseña Vacia";
		}
		if (empty($_POST["r_password"])) {
			$error .= "\n Recontraseña vacia";
		}
		else if ($_POST["password"] != $_POST["r_password"]) {
			$error .= "\n Las contraseñas no coinciden";
		}
		
		// fecha
		if (empty($_POST["date"])) {
			$error .= "\n Fecha de Nacimiento Vacia";
		}else if($_POST["date"]){
			if(!is_date($_POST['date'])) {
	            $validaciones['date'] = 'El campo fecha requiere una fecha válida dd/mm/yyyy';
	        }
		}

		if ($error != "") {
			echo $error;
		}else{
			// capturar datos
			require_once "process.php";
			$nombre = $_POST['first_name'];
			$apellido = $_POST['last_name'];
			$email = $_POST['email'];
			$password = md5($_POST['password']);
			$date = $_POST['date'];
			$fechaRegistro = date('Y-m-d');
			$query = "INSERT INTO usuario (nombre, apellido, correo, password, fechaNacimiento, fechaRegistro) VALUES ('".$nombre."', '".$apellido."', '".$email."', '".$password."', '".$date."', '".$fechaRegistro."')";
			function veryEmail($conexion, $email){
				$query = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo = '".$email."'");
	            if ($row = mysqli_fetch_array($query)){
	            	return false;
	            }else{
	            	return true;
	            }
	        }
	        $confiEmail = veryEmail($conexion, $email);
	        if ($confiEmail == true) {
				echo "Success";
				$sql->general($query);
	        }else{
	            echo "Error";
	        }
		}


	}


?>
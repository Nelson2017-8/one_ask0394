<?php  

 	define("server", "localhost");
    define("user", "root");
    define("pass", "");
    define("bd", "one-ask");


    class SQL
    {
        public function conectar(){
            $conexion=mysqli_connect(server, user, pass)or die(mysqli_error());
            mysqli_select_db($conexion, bd);
            return $conexion;
        }
        public function general($query){
            if (!mysqli_query(SQL::conectar(), $query)) die (@mysqli_error("Error al procesar los datos"));
            return true;
        }
        public function delete($tabla, $att, $codigo){
            if (!mysqli_query(SQL::conectar(), "DELETE FROM $tabla WHERE $att ='".$codigo."' LIMIT 1")) die (@mysqli_error("Error al eliminar el campo"));
            return true;
        }
        public function insertar($tabla, $campos, $values){
            if (!mysqli_query(SQL::conectar(), "INSERT INTO $tabla ($campos) VALUES ($values)")) die (@mysqli_error("Error al insertar el campo"));
            return true;
        }
        public function udpate($tabla, $campos, $condicion){
            if (!mysqli_query(SQL::conectar(), "UPDATE $tabla set $campos WHERE $condicion")) die (@mysqli_error("Error al actualizar los datos"));
            return true;
        }
    }

    $sql = new SQL;
    $conexion = $sql->conectar();
        

    class email
    {
        
        public function submit($destinatario, $asunto, $mensaje)
        {
            $cabeceras = 'MIME-Version: 1.0' . "\r\n";
            $cabeceras .= 'Content-type: text/html; charset=utf-8' . "\r\n";
            $cabeceras .= 'From: '.$destinatario;
            $aleatorio = uniqid(); //Genera un id único para identificar la cuenta a traves del correo, no usado

            if (!strpos($destinatario,"@hotmail.") && !strpos($destinatario,"@gmail.") && !strpos($destinatario,"@yahoo.") && !strpos($destinatario,"live.com.")){ 
                define("i_EmailEnviado","false");
            } else{
                if (mail($destinatario, $asunto, $mensaje, $cabeceras)){
                    define("i_EmailEnviado", "true");
                    return true;
                 }else{
                    define("i_EmailEnviado","false");
                    return false;
                } 
            }
            // return true;
        }

        // code email
        public function token_codeEmail(){
            $aleatorio = uniqid(40);
            $rand = rand(4444, 5555);
            $num = strtoupper(substr($aleatorio, 13,14));
            return $num."-".$rand;
        }
        public function token_obtenCaracterAleatorio($arreglo) {
            $clave_aleatoria = array_rand($arreglo, 1); //obten clave aleatoria
            return $arreglo[ $clave_aleatoria ];    //devolver item aleatorio
        }
        public function token_obtenCaracterMd5($car) {
            $md5Car = md5($car.Time()); //Codificar el caracter y el tiempo POSIX (timestamp) en md5
            $arrCar = str_split(strtoupper($md5Car));   //Convertir a array el md5
            $carToken = email::token_obtenCaracterAleatorio($arrCar);    //obten un item aleatoriamente
            return $carToken;
        }
        public function token_obtenToken($longitud) {
            //crear alfabeto
            $mayus = "ABCDEFGHIJKMNPQRSTUVWXYZ";
            $mayusculas = str_split($mayus);    //Convertir a array
            //crear array de numeros 0-9
            $numeros = range(0,9);
            //revolver arrays
            shuffle($mayusculas);
            shuffle($numeros);
            //Unir arrays
            $arregloTotal = array_merge($mayusculas,$numeros);
            $newToken = "";
            for($i=0;$i<=$longitud;$i++) {
                $miCar = email::token_obtenCaracterAleatorio($arregloTotal);
                $newToken .= email::token_obtenCaracterMd5($miCar);
            }
            return $newToken;
        }
    }
        
    $email = new email;

?>
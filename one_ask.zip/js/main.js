$(document).ready(function() {
	$('a[href="#"]').click(function(event) {
		event.preventDefault();

	});
	// $("#registro").validate({
	// 	rules: {
	// 		email: {
	// 			required: true,
	// 			email: true
	// 		},
	// 		password: {
	// 				required: true,
	// 				minlength: 5
	// 			}
	// 	},
	// 	messages: {
	// 		email: "Por favor ingrese un correo válido",
	// 		password: {
	// 			required: "Es requerido una contraseña para iniciar",
	// 			minlength: "Su contraseña no tiene el minimo de longitud aceptada"
	// 		}
	// 	}
	// });
	$("#registro").submit(function(e) {
		e.preventDefault();
		var data = $(this).serialize();
		var msj = $("#msj");
		var contect = $(".c-w100");
		$.ajax({
			url: '../../process/registro.php',
			type: 'POST',
			data: data,
			success: function (data) {
				console.log(data);
				if (data == "Success") {
					msj.html("El registro se ha completado con éxito");
					msj.removeClass('alert-danger alert-warning').addClass('alert-success');
					contect.addClass('add-c');
					location.href="../../";
				}if (data == "Error") {
					msj.html("El usuario ya esta registrado");
					msj.removeClass('alert-success alert-warning').addClass('alert-danger');
					contect.addClass('add-c');
				}
				// else{
				// 	msj.html("Error en los campos");
				// 	msj.addClass('mb-5 py-1 w100 alert alert-warning');
				// 	contect.addClass('add-c');
				// }
			},
			error: function(data){
				console.log(data);
				// msj.html(data);
			}
		});
		
	});
	// $("form").validate({
	// 	rules: {
	// 		email: {
	// 			required: true,
	// 			email: true
	// 		},
	// 		password: {
	// 				required: true,
	// 				minlength: 5
	// 			}
	// 	},
	// 	messages: {
	// 		email: "Por favor ingrese un correo válido",
	// 		password: {
	// 			required: "Es requerido una contraseña para iniciar",
	// 			minlength: "Su contraseña no tiene el minimo de longitud aceptada"
	// 		}
	// 	}
	// });
});


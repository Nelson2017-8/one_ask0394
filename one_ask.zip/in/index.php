<!DOCTYPE html>
<html lang="in">
<head>
	<title>Inicio de Sesión - One Ask</title>
	<link rel="stylesheet" href="../css/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="../css/style.css">

</head>
<body>

<nav class="navbar navbar-expand-lg	navbar-light bg-primary">
	<a	class="navbar-brand img-responsive img-logo" href="#"><img src="../img/logo/logo.png" alt="one_ask"><h1>One Ask</h1></a>
	<button	class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
</nav>

	<script src="../js/jquery-3.3.1.js"></script>
	<script src="../js/bootstrap/bootstrap.min.js"></script>
</body>
</html>